
package mx.itson.palindromo.business;

/**
 *
 * @author geniuslab
 */
public class Palindromo {
   /**
    *  validar si phrase nos dara el mismo resultado 
    * al revertirlo, se retirba true en caso de que sea verdadero
    * y false en caso de que no sea 
    * @param phrase es el valor que nos dara el usuario
    * @return boolean true o false
    */
    public static boolean esPalindromo(String phrase){
        String cleanPhrase = phrase.replace(" ", "").replace("!", "");
        String phreversed = new StringBuilder(cleanPhrase).reverse().toString();
        
        if (cleanPhrase.equals(phreversed)) {
            return true;
        }
        
        return false;
    }
    
    public String deshacer(String palindromoBueno){
        return palindromoBueno + "jajajaaj";
    }
    
    /**
     * Suma dos numeros enteros
     * @param a primero numero a sumar
     * @param b segundo numero a sumar
     * @return suma de los dos numeros 
     */
    public int sumar(int a, int b){
        int total = 0;
        try{
           total = a + b;
        }catch(Exception ex){
          System.err.print("No se pudo realizar la suma");
       }
        return total;
    }
}
